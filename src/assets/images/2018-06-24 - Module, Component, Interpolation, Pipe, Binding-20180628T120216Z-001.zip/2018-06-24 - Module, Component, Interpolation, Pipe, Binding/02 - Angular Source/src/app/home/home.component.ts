import { Component, OnInit, ViewEncapsulation, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css'],
    //encapsulation: ViewEncapsulation.None
})
export class HomeComponent implements OnInit, OnChanges, OnDestroy {

    public currentDiscount: number;
    public currentDate: Date;
    public imageWidth: number = 200;

    public decrease(event: Event): void {
        this.imageWidth -= 10;
        console.log(event);
    }

    public reset(): void {
        this.imageWidth = 200;
    }

    public increase(): void {
        this.imageWidth += 10;
    }


    /* מתבצע ברגע יצירת האובייקט */
    public constructor() { 
        console.log("constructor");
    }

    /* מתבצעת פעם אחת בחיי הרכיב, אחרי שהתצוגה מוכנה לשימוש */
    public ngOnInit(): void {
        console.log("ngOnInit");
        this.currentDiscount = 12; // From the server...
        this.currentDate = new Date();
    }

    /* מתבצעת בכל רגע שמתרחש שינוי כלשהו במידע של הרכיב */
    public ngOnChanges(changes: SimpleChanges): void {
        console.log("ngOnChanges", changes);
    }

    /* מתבצעת רגע לפני שהרכיב נהרס */
    public ngOnDestroy(): void {
        console.log("ngOnDestroy");
    }


}
